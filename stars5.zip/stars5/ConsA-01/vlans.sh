#!/bin/sh
vlans="1 273 529 785 1041 1297"
# set up VLANs
for vlanid in $vlans
  do
    ip link add link eth0 name eth0.$vlanid type vlan id $vlanid
  done
