#!/usr/bin/python3
import sys, math

# how long to run in simulated time (hours):
simperiod = 72
# number of seconds to advance simulated time:
simsecs = 432
# number of seconds real time to wait between iterations:
realsecs = 0.05
# talk to docker containers (0 = no, 1 = yes):
docker = 0
# for retrograde, 1 is a regular prograde orbit, -1 means a retrograde orbit

# with these codes in place, the screen will refresh in-place:
clearscreen = "\033[2J"
topscreen = "\033[0;0H"
clearrestofline = "\033[0K"

# with these uncommented, the screen will scroll:
#clearscreen = ""
#topscreen = ""
#clearrestofline = ""

range = 4300
earth = 6371

bheight = 600
bsats = [ 36, 108, 180, 252, 324 ]
bsatnums = [ "", 1, 2, 3, 4, 5 ]
bsatnames = [ "", "SIXP01", "SIXP02", "SIXP03", "SIXP04", "SIXP05" ]
binterfaces = [ "", "eth0.273", "eth0.289", "eth0.529", "eth0.545", "eth0.785", "eth0.801", "eth0.1041", "eth0.1057", "eth0.1297", "eth0.1313" ]
bperiod = 2 * math.pi * math.sqrt(pow((6371 + bheight) * 1000, 3) / (3.986 * pow(10, 14)))
bretrograde = 1

aheight = 500
asats = [ 0 ]
asatnums = [ "", 1 ]
asatnames = [ "", "ConsA-01" ]
ainterfaces = [ "", "eth0.273", "eth0.529", "eth0.785", "eth0.1041", "eth0.1297" ]
aup = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ]
aperiod = 2 * math.pi * math.sqrt(pow((6371 + aheight) * 1000, 3) / (3.986 * pow(10, 14)))
aretrograde = 1

cheight = 500
csats = [ 0 ]
csatnums = [ "", 1 ]
csatnames = [ "", "ConsC-01" ]
cinterfaces = [ "", "eth0.289", "eth0.545", "eth0.801", "eth0.1057", "eth0.1313" ]
cup = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ]
cperiod = 2 * math.pi * math.sqrt(pow((6371 + cheight) * 1000, 3) / (3.986 * pow(10, 14)))
cretrograde = 1

