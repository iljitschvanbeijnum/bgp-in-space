#!/bin/sh
vlans="2 289 545 801 1057 1313 1569"
# set up VLANs
for vlanid in $vlans
  do
    ip link add link eth0 name eth0.$vlanid type vlan id $vlanid
  done
