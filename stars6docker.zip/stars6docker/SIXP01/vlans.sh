#!/bin/sh
vlans="192 203 273 289 529 545 785 801 1041 1057 1297 1313 1553 1569"
# set up VLANs
for vlanid in $vlans
  do
    ip link add link eth0 name eth0.$vlanid type vlan id $vlanid
  done
